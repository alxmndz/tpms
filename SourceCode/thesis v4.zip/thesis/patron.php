<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Favicon-->
  	<link rel="icon" type="image/x-icon" href="assets/client.ico" />
	<title>Saint vincent Ferrer | Patron</title>
</head>
<body>
	<b>Patron</b>
</body>
</html>